# Handoff: KBJU scan screen (сканирование этикетки)

## Overview
Mobile app for tracking calories/macros (КБЖУ). This handoff covers the **label-scanning screen**: the camera viewfinder plus a live "recognition" panel that fills up frame by frame. Four visual directions are included; the product team has not yet picked one.

Key product idea: the app does **not** show a single finished result. Each captured frame increases confidence in each field, and the UI shows a **progress bar per field**:
- Required: **калории, белки, жиры, углеводы**
- Optional: **название**, **штрихкод** (must be visually de-emphasized and clearly marked as optional; the screen can be saved without them)
- A global "заполнено X%" indicator aggregates field progress.

Animation of the fill was NOT built yet — the mocks show a single frozen state (~72% overall, `углеводы` at 46%, `штрихкод` at 6%). The intended motion is described under "Interactions & Behavior".

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing intended look and layout, not production code to copy. The task is to **recreate these designs in the target codebase's environment** (React Native, SwiftUI, Kotlin/Compose, Flutter, web) using its established patterns, component library and design tokens. If no environment exists yet, pick the framework appropriate to the project and implement the designs there. Everything in the HTML is inline-styled on purpose (a streaming-preview constraint) — do not treat that as a styling recommendation.

## Fidelity
**High-fidelity** for the panel: colors, type, sizes and spacing below are final-intent values and should be reproduced closely. Two exceptions are deliberately low-fidelity:
- The **camera feed** is a diagonal striped placeholder with the caption `камера · этикетка`. Replace with the real camera preview.
- There are **no icons**; the ✎ / text buttons are placeholders. Use the codebase's icon set.

## Screens / Views

All four options are the same screen in the same state, on a 402 × 874 logical-px iPhone frame (`ios-frame.jsx` provides bezel, status bar, home indicator — **not part of the design**, it is scaffolding; the app screen is its 402 × 874 content area).

Shared anatomy, top to bottom:
1. **Camera layer** — fills the area above the panel.
2. **Top bar** (over camera, y ≈ 60–75) — screen label on the left, frame counter / hint on the right.
3. **Detection frame** — a rectangle the user aligns the label with, plus a scan accent.
4. **Result panel** — bottom sheet, fixed height, containing: global progress, product name, the four required field rows, a divider, the optional field(s), then the action row pinned to the bottom (`margin-top:auto`).

Copy used (verbatim, Russian): `сканирование` / `СКАН` / `скан кбжу`, `кадр 24 · 0.4 s`, `24 кадра`, `заполнено`, `72%`, `4 из 6 полей`, `обязательных: 3 / 4`, `осталось: углеводы`, `Держите этикетку в рамке`, `ЛОВИ ЭТИКЕТКУ`, `калории` `248 ккал`, `белки` `12,4 г`, `жиры` `8,1 г`, `углеводы` `46%` / `распознаём… 46%`, `название` `Творог 5%`, `штрихкод` `—`, `опц.` / `необяз.` / `не обяз.`, `ищем`, `Сохранить` / `СОХРАНИТЬ` / `добавить в день`, `Ввести вручную` / `вручную`, `почти готово`.

### Option 1a — "Приборная панель" (dark, technical)
- Screen bg `#0a0b0c`; panel `#101112`, height 330, top border `1px rgba(255,255,255,.09)`, padding `18px 20px 26px`, gap 14, **no corner radius**.
- Accent `oklch(.82 .13 190)` (cyan). Fonts: **IBM Plex Mono** (labels, values, buttons), IBM Plex Sans (product name).
- Detection frame: 4 corner brackets 26 × 26, `2px` accent, inset left/right 40, top 250, height 170; horizontal scan line `1px` accent with `box-shadow: 0 0 18px 2px oklch(.82 .13 190 / .55)` at mid-height.
- Global block: label `9px/1, ls .22em, uppercase, rgba(255,255,255,.4)`; number `500 34px` mono white with `16px` `%` at `rgba(255,255,255,.45)`; right-side meta `10px/1.4 rgba(255,255,255,.4)`. Rail: height 3, track `rgba(255,255,255,.1)`, radius 2, fill 72% accent.
- Required rows (gap 11): row = label `400 9px, ls .18em, uppercase, rgba(255,255,255,.45)` ↔ value `500 15px` white with `10px` unit at 40% opacity; below, rail height **2**, track `rgba(255,255,255,.1)`, fill accent. Incomplete row (`углеводы`) replaces the value with `распознаём… 46%` in `400 12px` accent and fills 46% at `opacity .75`.
- Optional fields: two equal columns (gap 10). Label at 32% opacity + a boxed `опц.` chip (`8px` mono, `1px rgba(255,255,255,.18)`, padding `1px 3px`); value `12px` sans at 80% (`Творог 5%`) or `rgba(255,255,255,.35)` placeholder `— · — · —`; rail height 2, track `rgba(255,255,255,.08)`, fill white 40% / 25% (88% and 6% width).
- Actions: primary flex-1, height 48, radius 10, bg accent, text `500 13px mono, ls .12em, uppercase, #04262b`; secondary 48 × 48, radius 10, `1px rgba(255,255,255,.16)`.

### Option 1b — "Тёплая карточка" (light, warm)
- Screen bg `#efe8db`; panel `#f7f2e8`, height 392, radius `28px 28px 0 0`, padding `22px 24px 28px`, gap 16.
- Ink `#2e2519`; muted `rgba(46,37,25,.55)`; tracks `rgba(60,48,32,.1)`. Macro colors, same L/C different hue: калории `oklch(.62 .13 40)`, белки `oklch(.62 .13 150)`, жиры `oklch(.62 .13 90)`, углеводы `oklch(.62 .13 250)`.
- Fonts: **Playfair Display** 400 for numbers and the product name, **Manrope** 500 for labels/UI.
- Viewfinder: rounded window, inset left/right 28, top 118, bottom 412, `1.5px rgba(255,255,255,.85)`, radius 26, dimmed surroundings via `box-shadow: 0 0 0 999px rgba(48,38,26,.28)`. Hint pill centered at y 64: `rgba(255,255,255,.92)`, radius 999, padding `8px 16px`, `500 11px` `#3c3020`.
- Global progress: 74 px donut, `conic-gradient(oklch(.62 .13 40) 0 72%, rgba(60,48,32,.12) 72%)`, 58 px inner disc in panel color, `72%` in Playfair 22. Beside it: product name Playfair 24, sub-line `12px/1.4` muted.
- Field row (gap 13): 74 px label column (`500 10px, ls .14em, uppercase, 50% ink`) → rail `flex:1`, height **6**, radius 3 → 64 px right column with the value in Playfair 19 (`248`, `12,4`, `8,1`) or `46%` in Manrope 12 muted.
- Optional `штрихкод`: after a `1px rgba(60,48,32,.12)` divider; two-line label (uppercase + lowercase `необяз.`) at 38% ink; rail height 4, track 8% ink, fill `rgba(46,37,25,.3)` at 6%; right column `ищем`.
- Actions: primary flex-1, height 50, radius 14, `#2e2519` bg, `#f7f2e8` text 14; secondary height 50, padding `0 18px`, radius 14, `1px rgba(46,37,25,.2)`, label `Ввести вручную`.

### Option 1c — "Контрастный" (black + acid)
- Screen bg `#0c0c0c`; panel height 418, padding `20px 24px 28px`, top border `2px` accent. Accent `oklch(.88 .19 125)`; track `#1a1a1a`; ring gap `#212121`. Font: **Unbounded** (700 display / 500 meta).
- Detection frame: inset 24, top 150, height 200, `2px` accent, radius 4, plus a 120 × 4 accent bar on the top-left edge.
- Top bar: `700 13px, ls .14em, uppercase` white; right chip accent bg, `700 10px` `#0c0c0c`.
- Global: 88 px donut `conic-gradient(accent 0 72%, #212121 72%)`, 66 px inner disc, `72` in 700 22 + `%` in 500 8 `ls .16em`; beside it two-line uppercase headline `почти готово` (700 20/1.1) and `осталось: углеводы` (500 11).
- **The field row IS the progress bar**: height 40, radius 8, track `#1a1a1a`, fill = accent at the field's confidence width, inner row `padding 0 14px, space-between`. Complete rows: full-width fill, label `700 11px ls .14em uppercase #0c0c0c` and value `700 15px #0c0c0c`. Incomplete row: fill 46% at `oklch(.88 .19 125 / .85)`, value `46%` in `rgba(255,255,255,.65)`. Row gap 8.
- Optional fields: dashed `1px rgba(255,255,255,.22)`, radius 8, height 36, side by side (`название` flex-1, `штрих` 118 px), label 500 10 at 45% white, value 500 11 white / 40% white.
- Action: single full-width block, height 54, radius 10, accent bg, `700 14px ls .16em uppercase #0c0c0c`, `добавить в день`.

### Option 2a — "Стена и стикеры" (graffiti / street art, warm)
Same warm sheet and row grid as 1b, street-art execution.
- Screen bg `#e9ddc6`; camera stripes `#cfc2a6 / #c7b99c`. Panel `#f4ecd8` + dot texture `radial-gradient(rgba(40,28,18,.07) 1px, transparent 1px)` at `7px 7px`, height 400, top border `3px #1d1710`, padding `26px 22px 26px`, gap 15.
- Ink `#1d1710`. Accents: magenta `oklch(.6 .19 350)`, yellow `oklch(.8 .18 95)`, green `oklch(.66 .17 150)`, blue `oklch(.58 .18 265)`.
- Fonts: **Russo One** 400 (display, numbers, primary button), **Rubik** 600 (labels/meta). Both have Cyrillic — required, see Assets.
- Viewfinder: inset 26, top 126, bottom 420, `3px` magenta border, `rotate(-1.2deg)`, offset block shadow `6px 6px 0 0 oklch(.8 .18 95)`, surroundings dimmed `0 0 0 999px rgba(30,22,14,.34)`. Sticker `ЛОВИ ЭТИКЕТКУ` above it: magenta bg, `rotate(-3deg)`, `white-space: nowrap`, Russo One 11, text `#fff8e6`.
- Top bar: `СКАН` Russo One 16 `#fff8e6` with layered hard shadows `2px 2px 0 magenta, 4px 4px 0 rgba(0,0,0,.35)`; right chip `#1d1710` bg, `rotate(1.5deg)`, Rubik 600 10 in yellow.
- Tape strip on the sheet edge: 132 × 26, `rgba(224,206,160,.85)`, dashed left/right borders, `rotate(-2deg)`, sitting at `top:-13px; left:96px`.
- Global: 78 px magenta donut with `box-shadow: 4px 4px 0 0 #1d1710`, inner 58 px disc, `72%` Russo One 17. Product name is a yellow highlighter chip (`padding 3px 8px`, `rotate(-1.5deg)`, Russo One 17). Meta `600 11px, ls .06em, uppercase, 60% ink`.
- Field row (gap 12): 76 px Rubik label (`600 10px, ls .16em, uppercase`, full ink) → rail `flex:1`, height **12**, `transform: skewX(-14deg)` (the "spray stroke"), track 12% ink, fill in the macro color → 62 px value in Russo One 15. Incomplete `углеводы`: 46% blue fill, value `46%` Rubik 600 12 at 60% ink.
- Divider: `3px #1d1710`, `rotate(-.6deg)`. Optional `штрихкод`: two-line Rubik label at 55%/45% ink, rail height 8 (also skewed), fill `rgba(29,23,16,.45)` at 6%, right text `ищем`.
- Actions: primary flex-1, height 52, **radius 0**, `#1d1710` bg, `box-shadow: 5px 5px 0 0 magenta`, Russo One 14 `#f4ecd8`; secondary height 52, padding `0 16px`, `2px #1d1710` border, Rubik 600 12 uppercase.

## Interactions & Behavior
Not yet prototyped — this is the intended behavior to implement (the next design iteration will specify motion precisely):
- **Per-frame accumulation.** Each analyzed camera frame yields a confidence 0…1 per field. Progress bars animate to the new confidence; they should only ever move forward (clamp to `max(prev, next)`) so the UI never appears to lose data. Suggested transition: width/transform `220–320 ms`, ease-out; never animate layout, only the fill.
- **Field completion.** A field is "готово" when confidence ≥ its threshold; at that moment the value snaps to its final formatted number, the rail goes to 100% in full accent, and the row gets a short emphasis beat (1a: rail brightens; 1b: value cross-fades in; 1c: fill reaches the end and label/value flip to `#0c0c0c`; 2a: stroke overshoots slightly, sticker-style).
- **Global progress** = weighted aggregate of required fields (optional fields contribute 0 to required-readiness, but still show their own bar). Counter reads `N из 6 полей` and `обязательных: N / 4`.
- **Scan hint** — the accent scan line (1a) / frame (1c) loops while scanning; frame counter increments live.
- **Optional fields never block.** Save is enabled once all 4 required fields are complete, regardless of `название` / `штрихкод`.
- **Manual fallback** — secondary action opens a manual-entry form pre-filled with whatever was recognized.
- Loading: before the first successful frame all bars are at 0 and the hint pill/`Держите этикетку в рамке` is shown. Error: recognition stalled → surface the manual-entry path.
- Reduced motion: honor the OS setting by jumping bars to their value without transition.

## State Management
```
scanning: boolean
frameCount: number
fields: {
  calories, protein, fat, carbs,        // required
  name, barcode                          // optional
} each: { value: string | null, confidence: 0..1, done: boolean }
overallPercent: derived
canSave: derived (all required.done)
```
Triggers: camera frame → recognition result → merge per field (monotonic confidence) → recompute derived values. Save → persist entry to the day's log.

## Design Tokens
Colors are listed per option above. Cross-cutting values:
- Screen: 402 × 874 logical px. Panel heights: 330 (1a) / 392 (1b) / 418 (1c) / 400 (2a).
- Radii: 0, 4, 8, 10, 14, 26, 28, 999.
- Rail heights: 2, 3, 4, 6, 8, 12; row heights 36, 40; buttons 48, 50, 52, 54.
- Spacing scale in use: 2, 3, 4, 5, 6, 8, 10, 11, 12, 13, 14, 16, 18, 20, 22, 24, 26, 28.
- Type sizes: 8, 9, 10, 11, 12, 13, 15, 17, 19, 20, 22, 24, 34; tracking .04–.24em on uppercase labels.
- Donut progress is a `conic-gradient` ring + inner disc in the panel color (swap for the platform's native ring/arc).

## Assets
- No images, no icons, no logos. The camera area is a striped placeholder.
- Fonts (Google Fonts, all **with Cyrillic subsets** — a hard requirement, the UI is Russian): IBM Plex Mono, IBM Plex Sans (1a); Playfair Display, Manrope (1b); Unbounded (1c); Russo One, Rubik (2a). Substitute only with Cyrillic-capable families.

## Files
- `Scan Styles.dc.html` — all four options on one canvas. Options are anchored: `#2a`, `#1a`, `#1b`, `#1c`; each is a `.dv-opt` block with a visible id badge and a note. Open in a browser to view.
- `ios-frame.jsx` — the iPhone bezel/status-bar scaffolding used by the mock. Reference only; do not port.
